/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/idea project/idea/mulop.vhd";
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_1547270861_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_1808404841_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_180853171_1035706684(char *, char *, int , int );
char *ieee_p_1242562249_sub_1919365254_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_2053728113_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_2778267465_1035706684(char *, char *, char *, char *, int );
unsigned char ieee_p_1242562249_sub_3472088553_1035706684(char *, char *, char *, char *, char *);


static void work_a_3400501926_3212880686_p_0(char *t0)
{
    char t8[16];
    char t14[16];
    char t15[16];
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned int t5;
    char *t6;
    char *t7;
    int t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned int t13;
    int t16;
    char *t17;
    char *t18;
    unsigned int t19;
    char *t20;
    char *t21;
    char *t22;
    unsigned int t23;

LAB0:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 5302);
    t4 = 1;
    if (16U == 16U)
        goto LAB5;

LAB6:    t4 = 0;

LAB7:    if (t4 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = ((IEEE_P_1242562249) + 3000);
    t6 = (t0 + 5048U);
    t1 = xsi_base_array_concat(t1, t8, t3, (char)99, (unsigned char)2, (char)97, t2, t6, (char)101);
    t7 = (t0 + 1648U);
    t10 = *((char **)t7);
    t7 = (t10 + 0);
    t5 = (1U + 16U);
    memcpy(t7, t1, t5);

LAB3:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 5318);
    t4 = 1;
    if (16U == 16U)
        goto LAB14;

LAB15:    t4 = 0;

LAB16:    if (t4 != 0)
        goto LAB11;

LAB13:    xsi_set_current_line(84, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = ((IEEE_P_1242562249) + 3000);
    t6 = (t0 + 5064U);
    t1 = xsi_base_array_concat(t1, t8, t3, (char)99, (unsigned char)2, (char)97, t2, t6, (char)101);
    t7 = (t0 + 1768U);
    t10 = *((char **)t7);
    t7 = (t10 + 0);
    t5 = (1U + 16U);
    memcpy(t7, t1, t5);

LAB12:    xsi_set_current_line(87, ng0);
    t1 = (t0 + 1648U);
    t2 = *((char **)t1);
    t1 = (t0 + 5096U);
    t3 = (t0 + 1768U);
    t6 = *((char **)t3);
    t3 = (t0 + 5112U);
    t7 = ieee_p_1242562249_sub_2053728113_1035706684(IEEE_P_1242562249, t8, t2, t1, t6, t3);
    t10 = (t0 + 1888U);
    t11 = *((char **)t10);
    t10 = (t11 + 0);
    t12 = (t8 + 12U);
    t5 = *((unsigned int *)t12);
    t13 = (1U * t5);
    memcpy(t10, t7, t13);
    xsi_set_current_line(88, ng0);
    t1 = (t0 + 1888U);
    t2 = *((char **)t1);
    t1 = (t0 + 5128U);
    t9 = xsi_vhdl_pow(2, 16);
    t3 = ieee_p_1242562249_sub_2778267465_1035706684(IEEE_P_1242562249, t14, t2, t1, t9);
    t6 = (t0 + 1888U);
    t7 = *((char **)t6);
    t6 = (t0 + 5128U);
    t16 = xsi_vhdl_pow(2, 16);
    t10 = ieee_p_1242562249_sub_1808404841_1035706684(IEEE_P_1242562249, t15, t7, t6, t16);
    t11 = ieee_p_1242562249_sub_1547270861_1035706684(IEEE_P_1242562249, t8, t3, t14, t10, t15);
    t12 = (t0 + 2008U);
    t17 = *((char **)t12);
    t12 = (t17 + 0);
    t18 = (t8 + 12U);
    t5 = *((unsigned int *)t18);
    t13 = (1U * t5);
    memcpy(t12, t11, t13);
    xsi_set_current_line(90, ng0);
    t1 = (t0 + 1888U);
    t2 = *((char **)t1);
    t1 = (t0 + 5128U);
    t9 = xsi_vhdl_pow(2, 16);
    t3 = ieee_p_1242562249_sub_2778267465_1035706684(IEEE_P_1242562249, t8, t2, t1, t9);
    t6 = (t0 + 1888U);
    t7 = *((char **)t6);
    t6 = (t0 + 5128U);
    t16 = xsi_vhdl_pow(2, 16);
    t10 = ieee_p_1242562249_sub_1808404841_1035706684(IEEE_P_1242562249, t14, t7, t6, t16);
    t4 = ieee_p_1242562249_sub_3472088553_1035706684(IEEE_P_1242562249, t3, t8, t10, t14);
    if (t4 != 0)
        goto LAB20;

LAB22:    xsi_set_current_line(93, ng0);
    t1 = (t0 + 2008U);
    t2 = *((char **)t1);
    t5 = (33 - 15);
    t13 = (t5 * 1U);
    t19 = (0 + t13);
    t1 = (t2 + t19);
    t3 = (t15 + 0U);
    t6 = (t3 + 0U);
    *((int *)t6) = 15;
    t6 = (t3 + 4U);
    *((int *)t6) = 0;
    t6 = (t3 + 8U);
    *((int *)t6) = -1;
    t9 = (0 - 15);
    t23 = (t9 * -1);
    t23 = (t23 + 1);
    t6 = (t3 + 12U);
    *((unsigned int *)t6) = t23;
    t16 = xsi_vhdl_pow(2, 16);
    t6 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t14, t1, t15, t16);
    t7 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t8, t6, t14, 1);
    t10 = (t0 + 3392);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t17 = (t12 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t7, 16U);
    xsi_driver_first_trans_fast_port(t10);

LAB21:    t1 = (t0 + 3312);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(77, ng0);
    t9 = xsi_vhdl_pow(2, 16);
    t10 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t8, t9, 17);
    t11 = (t0 + 1648U);
    t12 = *((char **)t11);
    t11 = (t12 + 0);
    memcpy(t11, t10, 17U);
    goto LAB3;

LAB5:    t5 = 0;

LAB8:    if (t5 < 16U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB6;

LAB10:    t5 = (t5 + 1);
    goto LAB8;

LAB11:    xsi_set_current_line(82, ng0);
    t9 = xsi_vhdl_pow(2, 16);
    t10 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t8, t9, 17);
    t11 = (t0 + 1768U);
    t12 = *((char **)t11);
    t11 = (t12 + 0);
    memcpy(t11, t10, 17U);
    goto LAB12;

LAB14:    t5 = 0;

LAB17:    if (t5 < 16U)
        goto LAB18;
    else
        goto LAB16;

LAB18:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB15;

LAB19:    t5 = (t5 + 1);
    goto LAB17;

LAB20:    xsi_set_current_line(91, ng0);
    t11 = (t0 + 2008U);
    t12 = *((char **)t11);
    t5 = (33 - 15);
    t13 = (t5 * 1U);
    t19 = (0 + t13);
    t11 = (t12 + t19);
    t17 = (t0 + 3392);
    t18 = (t17 + 56U);
    t20 = *((char **)t18);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t11, 16U);
    xsi_driver_first_trans_fast_port(t17);
    goto LAB21;

}


extern void work_a_3400501926_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3400501926_3212880686_p_0};
	xsi_register_didat("work_a_3400501926_3212880686", "isim/tb_trafo_isim_beh.exe.sim/work/a_3400501926_3212880686.didat");
	xsi_register_executes(pe);
}
